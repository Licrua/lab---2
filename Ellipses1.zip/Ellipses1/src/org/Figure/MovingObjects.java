package org.Figure;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class MovingObjects extends JPanel implements ActionListener {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int DELAY = 10;

    private List<Ellipse> ellipses;
    private Timer timer;
    private int activeObjectIndex;

    public MovingObjects() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.WHITE);

        initializeEllipses();

        timer = new Timer(DELAY, this);
        timer.start();
    }

    private void initializeEllipses() {
        ellipses = new ArrayList<>();
        ellipses.add(new Ellipse(50, 400, 50, 50, Color.RED));
        ellipses.add(new Ellipse(200, 300, 80, 60, Color.BLUE));
        ellipses.add(new Ellipse(350, 500, 30, 70, Color.GREEN));

        // Установка активного объекта в начале
        activeObjectIndex = 0;
    }

    private void moveObjects() {
        for (Ellipse ellipse : ellipses) {
            ellipse.move();
            ellipse.changeColor();

            // Проверка столкновения с активным объектом
            if (ellipse != ellipses.get(activeObjectIndex) && ellipse.intersects(ellipses.get(activeObjectIndex))) {
                ellipse.reverseDirectionX();
                ellipse.reverseDirectionY();
            }

            checkBoundaryCollision(ellipse);
        }
    }

    private void checkBoundaryCollision(Ellipse ellipse) {
        if (ellipse.getX() <= 0 || ellipse.getX() + ellipse.getWidth() >= WIDTH) {
            ellipse.reverseDirectionX();
        }
        if (ellipse.getY() <= 0 || ellipse.getY() + ellipse.getHeight() >= HEIGHT) {
            ellipse.reverseDirectionY();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        for (Ellipse ellipse : ellipses) {
            ellipse.draw(g2d);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        moveObjects();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Moving Objects");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(new MovingObjects());
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}

class Ellipse {
    private static final int SPEED = 2;

    private int x;
    private int y;
    private int width;
    private int height;
    private Color color;
    private int dx;
    private int dy;

    public Ellipse(int x, int y, int width, int height, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
        dx = SPEED;
        dy = SPEED;
    }

    public void move() {
        x += dx;
        y -= dy; // Движение вверх (уменьшение координаты y)
    }

    public void changeColor() {
        int red = (int) (Math.random() * 256);
        int green = (int) (Math.random() * 256);
        int blue = (int) (Math.random() * 256);
        color = new Color(red, green, blue);
    }

    public void reverseDirectionX() {
        dx = -dx;
    }

    public void reverseDirectionY() {
        dy = -dy;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public boolean intersects(Ellipse other) {
        Ellipse2D ellipse1 = new Ellipse2D.Double(x, y, width, height);
        Ellipse2D ellipse2 = new Ellipse2D.Double(other.x, other.y, other.width, other.height);
        return ellipse1.intersects(ellipse2.getBounds2D());
    }

    public void draw(Graphics2D g2d) {
        g2d.setColor(color);
        g2d.fill(new Ellipse2D.Double(x, y, width, height));
    }
}
